Template.Settings.helpers({});
Template.Settings.events({});