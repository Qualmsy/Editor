Template.Styles.helpers({
	isComponent: function () {
		var c = State.CurrentComponent.get();
		
	}
});
Template.Styles.events({
	"change #defineStyle": function (event, tmpl) {

	}
});