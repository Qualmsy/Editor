Template.Functions.helpers({

});
Template.Functions.events({

});