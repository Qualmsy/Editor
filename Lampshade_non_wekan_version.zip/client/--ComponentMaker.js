Template.ComponentMaker.helpers({

});
Template.ComponentMaker.events({

});