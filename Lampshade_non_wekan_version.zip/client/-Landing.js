Template.Landing.helpers({
	Project: function () {
		return Projects.find();
	}
});
Template.Landing.events({
	"click #ProjectsListTable": function (event, template) {

	}


});