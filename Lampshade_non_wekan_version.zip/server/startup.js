Meteor.startup(function () {
 console.log(cheerio.load("<div>sd</div>"));
});