nodeHelpers = {};
nodeHelpers.types = {};
